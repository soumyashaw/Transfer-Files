file1 = "eval_CM_scores_OutofDist_Amazon.txt"
file2 = "eval_CM_scores_OutofDist_DiffGAN.txt"
file3 = "eval_CM_scores_OutofDist_ElevenLabs.txt"
file4 = "eval_CM_scores_OutofDist_fastspeech2.txt"
file5 = "eval_CM_scores_OutofDist_Google.txt"
file6 = "eval_CM_scores_OutofDist_transformer.txt"
file7 = "eval_CM_scores_OutofDist_vits.txt"

target = "eval_CM_scores_OutofDist.txt"

with open(file1, 'r') as f1:
    with open(target, 'a') as t:
        for line in f1:
            t.write(line)

with open(file2, 'r') as f2:
    with open(target, 'a') as t:
        for line in f2:
            t.write(line)

with open(file3, 'r') as f3:
    with open(target, 'a') as t:
        for line in f3:
            t.write(line)

with open(file4, 'r') as f4:
    with open(target, 'a') as t:
        for line in f4:
            t.write(line)

with open(file5, 'r') as f5:
    with open(target, 'a') as t:
        for line in f5:
            t.write(line)

with open(file6, 'r') as f6:
    with open(target, 'a') as t:
        for line in f6:
            t.write(line)

with open(file7, 'r') as f7:
    with open(target, 'a') as t:
        for line in f7:
            t.write(line)
