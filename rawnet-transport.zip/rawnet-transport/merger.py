import os

# Define the directory containing the text files
directory_path = '/home/soumyas_kvmohan/rawnet2-antispoofing/ASVspoof2021'

# Define the name of the output file
output_file_path = 'merged_file.txt'

# Get a list of all text files in the directory
text_files = [f for f in os.listdir(directory_path) if f.endswith('.txt')]

# Open the output file in write mode
with open(output_file_path, 'w') as output_file:
    # Iterate through each text file
    for file_name in text_files:
        # Construct the full file path
        file_path = os.path.join(directory_path, file_name)
        # Open the current text file in read mode
        with open(file_path, 'r') as file:
            # Read the content of the file
            content = file.read()
            # Write the content to the output file
            output_file.write(content)

print(f'All files have been merged into {output_file_path}')

