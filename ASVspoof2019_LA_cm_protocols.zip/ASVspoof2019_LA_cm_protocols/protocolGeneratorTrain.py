import os

filename = "original_ASVspoof2019.LA.cm.train.trn.txt"
dict = {}

with open(filename, "r") as file1:
    for line in file1:
        line = line.strip().split()
        dict[line[1]] = line[4]
        
loc1 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/ambient_noise_old_incomplete/'
loc2 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/codec_losses/'
loc3 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/downsampling/'
loc4 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/gaussian_noise/'
loc5 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/packet_loss/'
loc6 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/reverberations/'
loc7 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/volume_reduction/'
loc8 = '/home/soumyas_kvmohan/ASVspoof2019/LA/ASVspoof2019_LA_train/flac/'

loc1_files = os.listdir(loc1)
loc2_files = os.listdir(loc2)
loc3_files = os.listdir(loc3)
loc4_files = os.listdir(loc4)
loc5_files = os.listdir(loc5)
loc6_files = os.listdir(loc6)
loc7_files = os.listdir(loc7)
loc8_files = os.listdir(loc8)

dict1 = {}
for file in loc1_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict1[original_file] = dict[file]

dict2 = {}
for file in loc2_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict2[original_file] = dict[file]

dict3 = {}
for file in loc3_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict3[original_file] = dict[file]

dict4 = {}
for file in loc4_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict4[original_file] = dict[file]

dict5 = {}
for file in loc5_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict5[original_file] = dict[file]

dict6 = {}
for file in loc6_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict6[original_file] = dict[file]

dict7 = {}
for file in loc7_files:
    original_file = file[:-5]
    file = file[-17:-5]
    dict7[original_file] = dict[file]

dict8 = {}
for file in loc8_files:
    original_file = file[:-5]
    file = file[:-5]
    dict8[original_file] = dict[file]


with open("protocol.txt", "w") as file2:

    key1 = list(dict1.keys())
    for k1 in key1:
        file2.write(f"LA_0000 {k1} - - {dict1[k1]}\n")

    key2 = list(dict2.keys())
    for k2 in key2:
        file2.write(f"LA_0000 {k2} - - {dict2[k2]}\n")

    key3 = list(dict3.keys())
    for k3 in key3:
        file2.write(f"LA_0000 {k3} - - {dict3[k3]}\n")

    key4 = list(dict4.keys())
    for k4 in key4:
        file2.write(f"LA_0000 {k4} - - {dict4[k4]}\n")

    key5 = list(dict5.keys())
    for k5 in key5:
        file2.write(f"LA_0000 {k5} - - {dict5[k5]}\n")

    key6 = list(dict6.keys())
    for k6 in key6:
        file2.write(f"LA_0000 {k6} - - {dict6[k6]}\n")

    key7 = list(dict7.keys())
    for k7 in key7:
        file2.write(f"LA_0000 {k7} - - {dict7[k7]}\n")

    key8 = list(dict8.keys())
    for k8 in key8:
        file2.write(f"LA_0000 {k8} - - {dict8[k8]}\n")
